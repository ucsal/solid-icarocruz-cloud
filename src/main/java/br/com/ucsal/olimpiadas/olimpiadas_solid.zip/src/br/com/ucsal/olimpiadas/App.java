package br.com.ucsal.olimpiadas;

import br.com.ucsal.olimpiadas.service.*;
import java.util.*;

public class App {

    static final List<Participante> participantes = new ArrayList<>();
    static final List<Prova> provas = new ArrayList<>();

    static long participanteId = 1;
    static long provaId = 1;

    private static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {

        ParticipanteService participanteService =
                new ParticipanteService(participantes, participanteId);

        ProvaService provaService =
                new ProvaService(provas, provaId);

        NotaService notaService = new NotaService();

        while (true) {
            System.out.println("\n1) Cadastrar participante");
            System.out.println("2) Cadastrar prova");
            System.out.println("0) Sair");

            switch (in.nextLine()) {
                case "1" -> {
                    System.out.print("Nome: ");
                    String nome = in.nextLine();

                    System.out.print("Email: ");
                    String email = in.nextLine();

                    try {
                        var p = participanteService.cadastrar(nome, email);
                        System.out.println("Criado: " + p.getId());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                }

                case "2" -> {
                    System.out.print("Título: ");
                    String titulo = in.nextLine();

                    try {
                        var p = provaService.cadastrar(titulo);
                        System.out.println("Prova criada: " + p.getId());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                }

                case "0" -> {
                    return;
                }
            }
        }
    }
}
