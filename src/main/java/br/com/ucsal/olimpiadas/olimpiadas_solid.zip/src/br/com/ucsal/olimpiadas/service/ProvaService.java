package br.com.ucsal.olimpiadas.service;

import br.com.ucsal.olimpiadas.Prova;
import java.util.List;

public class ProvaService {

    private final List<Prova> provas;
    private long proximoId;

    public ProvaService(List<Prova> provas, long proximoId) {
        this.provas = provas;
        this.proximoId = proximoId;
    }

    public Prova cadastrar(String titulo) {
        if (titulo == null || titulo.isBlank()) {
            throw new IllegalArgumentException("Título inválido");
        }

        Prova prova = new Prova();
        prova.setId(proximoId++);
        prova.setTitulo(titulo);

        provas.add(prova);
        return prova;
    }
}
